# codefair
CDU Assignment 2 Code Fair

Josh Bauer
Kris Bebbington
